package com.android.pantaparaunion;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;


public class Seba_Somuho extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_seba__somuho);
		
		TextView tv = (TextView) this.findViewById(R.id.textView1);  
        tv.setSelected(true); 
		Typeface font1 = Typeface.createFromAsset
				(getAssets(), "azad.ttf");
		   Button button1 = (Button) findViewById(R.id.button1);
	        button1.setOnClickListener(new OnClickListener() {

	            @Override
	            public void onClick(View view) {
	                // TODO Auto-generated method stub
	            	Intent i = new Intent(Seba_Somuho.this,Digital.class);
	             	startActivity(i);
	        	
	 				
	 			}
	 		});
	}

	

	 @Override
	    public boolean onCreateOptionsMenu(Menu menu) {
	        // Inflate the menu; this adds items to the action bar if it is present.
	        getMenuInflater().inflate(R.menu.main, menu);
	        return true;
	    }
	 
@Override
public boolean onOptionsItemSelected(MenuItem item) {
	switch(item.getItemId()){
	case R.id.share:
		Intent shareIntent = new Intent(Intent.ACTION_SEND);
		shareIntent.setType("text/plain");
		shareIntent.putExtra(Intent.EXTRA_SUBJECT, "subject here");
		shareIntent.putExtra(Intent.EXTRA_TEXT, "body here");
		startActivity(Intent.createChooser(shareIntent, "Share Via"));
		break;
	default:
		break;
	
	}
	return true;
}

}

