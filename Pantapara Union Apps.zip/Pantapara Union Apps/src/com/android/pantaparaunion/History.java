package com.android.pantaparaunion;

import android.os.Bundle;
import android.webkit.WebView;
import android.app.Activity;


public class History extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_history);
		WebView mWebView = null;
		mWebView = (WebView)findViewById(R.id.webView1);
		mWebView.getSettings().setJavaScriptEnabled(true);
		mWebView. loadUrl("file:///android_asset/History.htm");
}
}