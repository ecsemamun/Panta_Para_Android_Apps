package com.android.pantaparaunion;





import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;


public class UnionSompokitoo extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_union_sompokitoo);
		Typeface font1 = Typeface.createFromAsset
				(getAssets(), "azad.ttf");
		final Animation animAlpha = AnimationUtils.loadAnimation(this,
				R.anim.anim_alpha);
	
		 TextView tv = (TextView) this.findViewById(R.id.textView1);  
	        tv.setSelected(true); 
	        
	        Button button1 = (Button) findViewById(R.id.button1);
	        button1.setOnClickListener(new OnClickListener() {

	            @Override
	            public void onClick(View view) {
	                // TODO Auto-generated method stub
	            	Intent i = new Intent(UnionSompokitoo.this,Union_Poricity.class);
	                startActivity(i);
					view.startAnimation(animAlpha);
					
				}
			});
	        Button button2 = (Button) findViewById(R.id.button2);
	        button2.setOnClickListener(new OnClickListener() {

	            @Override
	            public void onClick(View view) {
	                // TODO Auto-generated method stub
	            	Intent i = new Intent(UnionSompokitoo.this,History.class);
	                startActivity(i);
					view.startAnimation(animAlpha);
					
				}
			});
	        Button button3 = (Button) findViewById(R.id.button3);
	        button3.setOnClickListener(new OnClickListener() {

	            @Override
	            public void onClick(View view) {
	                // TODO Auto-generated method stub
	            	Intent i = new Intent(UnionSompokitoo.this,Khal.class);
	                startActivity(i);
					view.startAnimation(animAlpha);
					
				}
			});
	        
	        
	}

	

}
