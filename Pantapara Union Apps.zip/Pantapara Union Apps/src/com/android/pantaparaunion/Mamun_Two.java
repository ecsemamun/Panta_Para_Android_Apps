package com.android.pantaparaunion;


import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class Mamun_Two extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_aboutme);
		
		Typeface font1 = Typeface.createFromAsset
				(getAssets(), "azad.ttf");
		
		Button button1 = (Button) findViewById(R.id.button1);
        button1.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
            	
            	
            	Intent i = new Intent(Mamun_Two.this,Mamun_Three.class);
                startActivity(i);
     
		
            }
        });
		
	
	}

	@Override
	protected void onUserLeaveHint() {
		Toast.makeText(Mamun_Two. this, "Mamun 01757828572 & 01960940494", Toast.LENGTH_LONG).show();
		super.onUserLeaveHint();
	}


	 @Override
	    public boolean onCreateOptionsMenu(Menu menu) {
	        // Inflate the menu; this adds items to the action bar if it is present.
	        getMenuInflater().inflate(R.menu.main, menu);
	        return true;
	    }
	 
@Override
public boolean onOptionsItemSelected(MenuItem item) {
	switch(item.getItemId()){
	case R.id.share:
		Intent shareIntent = new Intent(Intent.ACTION_SEND);
		shareIntent.setType("text/plain");
		shareIntent.putExtra(Intent.EXTRA_SUBJECT, "subject here");
		shareIntent.putExtra(Intent.EXTRA_TEXT, "Md.Abdulla Al Mamun" +
				"Web & Android Apps Developer" +
				"Jhenaidah Govt. Polytechnic Institute" +
				"Diploma In Engineering Of Computer" +
				"Skype: mamuncmt" +
				"Mobile 01757828572" +
				"01960940494" +
				"Email" +
				"mamunkazigp@gmail.com");
		startActivity(Intent.createChooser(shareIntent, "Share Via"));
		break;
	default:
		break;
	
	}
	return true;
}

}
