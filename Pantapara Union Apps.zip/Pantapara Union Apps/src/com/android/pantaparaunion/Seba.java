package com.android.pantaparaunion;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;


public class Seba extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_seba);
		final Animation animAlpha = AnimationUtils.loadAnimation(this,
				R.anim.anim_alpha);
		final Animation animScale = AnimationUtils.loadAnimation(this,
				R.anim.anim_scale);
		final Animation animRotate = AnimationUtils.loadAnimation(this,
				R.anim.anim_rotate);
		TextView tv = (TextView) this.findViewById(R.id.textView1);  
        tv.setSelected(true); 
		Typeface font1 = Typeface.createFromAsset
				(getAssets(), "azad.ttf");
		//To add song when application starts.
				MediaPlayer mediaStart = MediaPlayer.create(this,  R.raw.chimes);
				mediaStart.start();
				final MediaPlayer media = MediaPlayer.create(this, R.raw.chimes);
    	Button button5 = (Button) findViewById(R.id.button5);
        button5.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
            	Intent i = new Intent(Seba.this,Bus.class);
                startActivity(i);
                media.start();
            }
        });
        
    	Button button6 = (Button) findViewById(R.id.button6);
        button6.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
            	Intent i = new Intent(Seba.this,Speech.class);
                startActivity(i);
                media.start();
            }
        });
        Button button4 = (Button) findViewById(R.id.button4);
        button4.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View view) {
                // TODO Auto-generated method stub
            	Intent i = new Intent(Seba.this,Mamun_Two.class);
            	AnimationSet sets = new AnimationSet(false);
				sets.addAnimation(animAlpha);
				sets.addAnimation(animScale);
				sets.addAnimation(animRotate);
			
                startActivity(i);
           				view.startAnimation(animScale);
           				media.start();
           				
           			}
           		});
		
	}

	

	 @Override
	    public boolean onCreateOptionsMenu(Menu menu) {
	        // Inflate the menu; this adds items to the action bar if it is present.
	        getMenuInflater().inflate(R.menu.main, menu);
	        return true;
	    }
	 
@Override
public boolean onOptionsItemSelected(MenuItem item) {
	switch(item.getItemId()){
	case R.id.share:
		Intent shareIntent = new Intent(Intent.ACTION_SEND);
		shareIntent.setType("text/plain");
		shareIntent.putExtra(Intent.EXTRA_SUBJECT, "subject here");
		shareIntent.putExtra(Intent.EXTRA_TEXT, "body here");
		startActivity(Intent.createChooser(shareIntent, "Share Via"));
		break;
	default:
		break;
	
	}
	return true;
}

}

