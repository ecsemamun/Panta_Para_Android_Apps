package com.android.pantaparaunion;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;


public class Union_Poricity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_union__poricity);
		final Animation animAlpha = AnimationUtils.loadAnimation(this,
				R.anim.anim_alpha);
		TextView tv = (TextView) this.findViewById(R.id.textView1);  
        tv.setSelected(true); 
		Typeface font1 = Typeface.createFromAsset
				(getAssets(), "azad.ttf");
		
		 Button button1 = (Button) findViewById(R.id.button1);
	        button1.setOnClickListener(new OnClickListener() {

	            @Override
	            public void onClick(View view) {
	                // TODO Auto-generated method stub
	            	Intent i = new Intent(Union_Poricity.this,Aknojor_Union.class);
	            	startActivity(i);
		view.startAnimation(animAlpha);
					
				}
			});
	        Button button2 = (Button) findViewById(R.id.button2);
	        button2.setOnClickListener(new OnClickListener() {

	            @Override
	            public void onClick(View view) {
	                // TODO Auto-generated method stub
	            	Intent i = new Intent(Union_Poricity.this,Map_Up.class);
	            	startActivity(i);
		view.startAnimation(animAlpha);
					
				}
			});
	        
	        
	        Button button3 = (Button) findViewById(R.id.button3);
	        button3.setOnClickListener(new OnClickListener() {

	            @Override
	            public void onClick(View view) {
	                // TODO Auto-generated method stub
	            	Intent i = new Intent(Union_Poricity.this,Gramvittik.class);
	            	startActivity(i);
		view.startAnimation(animAlpha);
					
				}
			});
	        
	        Button button4 = (Button) findViewById(R.id.button4);
	        button4.setOnClickListener(new OnClickListener() {

	            @Override
	            public void onClick(View view) {
	                // TODO Auto-generated method stub
	            	Intent i = new Intent(Union_Poricity.this,Zogagog.class);
	            	startActivity(i);
		view.startAnimation(animAlpha);
					
				}
			});
	        
		
	}

	

	 @Override
	    public boolean onCreateOptionsMenu(Menu menu) {
	        // Inflate the menu; this adds items to the action bar if it is present.
	        getMenuInflater().inflate(R.menu.main, menu);
	        return true;
	    }
	 
@Override
public boolean onOptionsItemSelected(MenuItem item) {
	switch(item.getItemId()){
	case R.id.share:
		Intent shareIntent = new Intent(Intent.ACTION_SEND);
		shareIntent.setType("text/plain");
		shareIntent.putExtra(Intent.EXTRA_SUBJECT, "subject here");
		shareIntent.putExtra(Intent.EXTRA_TEXT, "body here");
		startActivity(Intent.createChooser(shareIntent, "Share Via"));
		break;
	default:
		break;
	
	}
	return true;
}

}

