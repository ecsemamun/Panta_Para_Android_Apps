package com.android.pantaparaunion;

import android.os.Bundle;
import android.webkit.WebView;
import android.app.Activity;


public class Bortoman extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_bortoman);
		WebView mWebView = null;
		mWebView = (WebView)findViewById(R.id.webView1);
		mWebView.getSettings().setJavaScriptEnabled(true);
		mWebView. loadUrl("file:///android_asset/Bortoman.htm");
	}
}
