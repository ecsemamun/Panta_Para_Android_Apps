package com.android.pantaparaunion;

import android.os.Bundle;
import android.webkit.WebView;
import android.app.Activity;

public class Biddaloy extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_biddaloy);
		WebView mWebView = null;
		mWebView = (WebView)findViewById(R.id.webView1);
		mWebView.getSettings().setJavaScriptEnabled(true);
		mWebView. loadUrl("file:///android_asset/Biddaloy.htm");
	}
}
