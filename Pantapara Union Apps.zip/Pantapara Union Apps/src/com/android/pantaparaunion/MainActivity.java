package com.android.pantaparaunion;




import android.os.Bundle;
import android.preference.PreferenceManager;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DigitalClock;
import android.widget.Toast;

public class MainActivity extends Activity {
	Context mContext = MainActivity.this;
	SharedPreferences appPreferences;
	boolean isAppInstalled = false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		DigitalClock digitalClock = (DigitalClock) findViewById(R.id.digitalClock);
		Typeface font1 = Typeface.createFromAsset
				(getAssets(), "azad.ttf");
		
		 Button button1 = (Button) findViewById(R.id.button1);
	        button1.setOnClickListener(new OnClickListener() {

	            @Override
	            public void onClick(View v) {
	                // TODO Auto-generated method stub
	            	Intent i = new Intent(MainActivity.this,New_Page.class);
	                startActivity(i);
	            }
	        });
	        
	        Button button2 = (Button) findViewById(R.id.button2);
	        button2.setOnClickListener(new OnClickListener() {

	            @Override
	            public void onClick(View v) {
	                // TODO Auto-generated method stub
	            	Intent i = new Intent(MainActivity.this,Seba.class);
	                startActivity(i);
	            }
	        });
	        
		
		
		
		appPreferences = PreferenceManager.getDefaultSharedPreferences(this);
		isAppInstalled = appPreferences.getBoolean("isAppInstalled", false);
		if(isAppInstalled == false)
		{ 
			Intent shortcutIntent = new Intent(getApplicationContext(),MainActivity.class);
			shortcutIntent.setAction(Intent.ACTION_MAIN);
			Intent intent = new Intent();
			intent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, shortcutIntent);
			intent.putExtra(Intent.EXTRA_SHORTCUT_NAME, "Computer Jhpi");
			intent.putExtra(Intent.EXTRA_SHORTCUT_ICON_RESOURCE, Intent.ShortcutIconResource.fromContext(getApplicationContext(), R.drawable.ic_launcher));
			intent.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
			getApplicationContext().sendBroadcast(intent);
			
			SharedPreferences.Editor editor = appPreferences.edit();
			editor.putBoolean("isAppInstalled", true);
			editor.commit();
		
		}
		
		
	
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		createDialog();
	}

	private void createDialog() {
		// TODO Auto-generated method stub
		AlertDialog.Builder alertDlg = new AlertDialog.Builder(this);
		alertDlg.setMessage("Are You Sure Want To Exit?");
		alertDlg.setCancelable(false);
		
		alertDlg.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				MainActivity.super.onBackPressed();
				
				
			}
		});
		alertDlg.setNegativeButton("No", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				
			}
		});
		
		alertDlg.create().show();
	
	}

	@Override
	protected void onUserLeaveHint() {
		Toast.makeText(MainActivity. this, "Thank You For Visit Our App", Toast.LENGTH_LONG).show();
		super.onUserLeaveHint();
	}

	 @Override
	    public boolean onCreateOptionsMenu(Menu menu) {
	        // Inflate the menu; this adds items to the action bar if it is present.
	        getMenuInflater().inflate(R.menu.main, menu);
	        return true;
	    }
	 
@Override
public boolean onOptionsItemSelected(MenuItem item) {
	switch(item.getItemId()){
	case R.id.share:
		Intent shareIntent = new Intent(Intent.ACTION_SEND);
		shareIntent.setType("text/plain");
		shareIntent.putExtra(Intent.EXTRA_SUBJECT, "subject here");
		shareIntent.putExtra(Intent.EXTRA_TEXT, "body here");
		startActivity(Intent.createChooser(shareIntent, "Share Via"));
		break;
	default:
		break;
	
	}
	return true;
}

}

