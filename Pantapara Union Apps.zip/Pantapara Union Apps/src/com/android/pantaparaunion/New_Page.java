package com.android.pantaparaunion;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;

import android.widget.Button;




public class New_Page extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_new__page);
		
		
		final Animation animAlpha = AnimationUtils.loadAnimation(this,
				R.anim.anim_alpha);
		final Animation animScale = AnimationUtils.loadAnimation(this,
				R.anim.anim_scale);
		final Animation animRotate = AnimationUtils.loadAnimation(this,
				R.anim.anim_rotate);
		
		
		Typeface font1 = Typeface.createFromAsset
				(getAssets(), "azad.ttf");
		
		
		//To add song when application starts.
		MediaPlayer mediaStart = MediaPlayer.create(this,  R.raw.chimes);
		mediaStart.start();

		final MediaPlayer media = MediaPlayer.create(this, R.raw.chimes);
		final MediaPlayer media1 = MediaPlayer.create(this, R.raw.chimes);
		
		
		Button button1 = (Button) findViewById(R.id.button1);
        button1.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View view) {
                // TODO Auto-generated method stub
            	
            	media.start();
            	
            	Intent i = new Intent(New_Page.this,UnionSompokitoo.class);
                startActivity(i);
           				view.startAnimation(animScale);
           				
           			}
           		});
	
        
    	Button button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View view) {
                // TODO Auto-generated method stub
            	
            	media1.start();
            	Intent i = new Intent(New_Page.this,Union_Porishod.class);
                startActivity(i);
           				view.startAnimation(animScale);
           				
           			}
           		});
        
        Button button3 = (Button) findViewById(R.id.button3);
        button3.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View view) {
                // TODO Auto-generated method stub
            	
            	media1.start();
            	Intent i = new Intent(New_Page.this,Sorkari_Office.class);
                startActivity(i);
           				view.startAnimation(animScale);
           				
           			}
           		});
        Button button4 = (Button) findViewById(R.id.button4);
        button4.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View view) {
                // TODO Auto-generated method stub
            	
            	media1.start();
            	Intent i = new Intent(New_Page.this,Etc_Potistan.class);
                startActivity(i);
           				view.startAnimation(animScale);
           				
           			}
           		});
        Button button5 = (Button) findViewById(R.id.button5);
        button5.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View view) {
                // TODO Auto-generated method stub
            	
            	media1.start();
            	Intent i = new Intent(New_Page.this,Etc_Talika.class);
                startActivity(i);
           				view.startAnimation(animScale);
           				
           			}
           		});
        
        
        Button button7 = (Button) findViewById(R.id.button7);
        button7.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View view) {
                // TODO Auto-generated method stub
            	
            	media1.start();
            	Intent i = new Intent(New_Page.this,Seba_Somuho.class);
                startActivity(i);
           				view.startAnimation(animScale);
           				
           			}
           		});
		Button button8 = (Button) findViewById(R.id.button8);
        button8.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View view) {
                // TODO Auto-generated method stub
            	
            	
            	Intent i = new Intent(New_Page.this,Aboutme.class);
            	AnimationSet sets = new AnimationSet(false);
				sets.addAnimation(animAlpha);
				sets.addAnimation(animScale);
				sets.addAnimation(animRotate);
			
                startActivity(i);
           				view.startAnimation(animScale);
           				
           			}
           		});
	}
	
	
	


	 @Override
	    public boolean onCreateOptionsMenu(Menu menu) {
	        // Inflate the menu; this adds items to the action bar if it is present.
	        getMenuInflater().inflate(R.menu.main, menu);
	        return true;
	    }
	 
@Override
public boolean onOptionsItemSelected(MenuItem item) {
	switch(item.getItemId()){
	case R.id.share:
		Intent shareIntent = new Intent(Intent.ACTION_SEND);
		shareIntent.setType("text/plain");
		shareIntent.putExtra(Intent.EXTRA_SUBJECT, "subject here");
		shareIntent.putExtra(Intent.EXTRA_TEXT, "body here");
		startActivity(Intent.createChooser(shareIntent, "Share Via"));
		break;
	default:
		break;
	
	}
	return true;
}

}


