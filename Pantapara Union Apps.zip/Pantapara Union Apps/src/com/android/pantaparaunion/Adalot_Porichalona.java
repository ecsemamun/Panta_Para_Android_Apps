package com.android.pantaparaunion;

import android.os.Bundle;
import android.app.Activity;
import android.webkit.WebView;

public class Adalot_Porichalona extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_adalot__porichalona);
		
		WebView mWebView = null;
		mWebView = (WebView)findViewById(R.id.webView1);
		mWebView.getSettings().setJavaScriptEnabled(true);
		mWebView. loadUrl("file:///android_asset/adalotporichalona.htm");
	}

	

}
