package com.android.pantaparaunion;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;


public class Sorkari_Office extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_sorkari__office);
		TextView tv = (TextView) this.findViewById(R.id.textView1);  
        tv.setSelected(true); 
		Typeface font1 = Typeface.createFromAsset
				(getAssets(), "azad.ttf");
		Button button1 = (Button) findViewById(R.id.button1);
        button1.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
            	
            	
            	Intent i = new Intent(Sorkari_Office.this,Health.class);
                startActivity(i);
     
		
            }
        });
		Button button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
            	
            	
            	Intent i = new Intent(Sorkari_Office.this,Krishi.class);
                startActivity(i);
     
		
            }
        });
        Button button3 = (Button) findViewById(R.id.button3);
        button3.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
            	
            	
            	Intent i = new Intent(Sorkari_Office.this,Vhumi.class);
                startActivity(i);
     
		
            }
        });
        Button button4 = (Button) findViewById(R.id.button4);
        button4.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
            	
            	
            	Intent i = new Intent(Sorkari_Office.this,Somaj.class);
                startActivity(i);
     
		
            }
        });
	}

	

	 @Override
	    public boolean onCreateOptionsMenu(Menu menu) {
	        // Inflate the menu; this adds items to the action bar if it is present.
	        getMenuInflater().inflate(R.menu.main, menu);
	        return true;
	    }
	 
@Override
public boolean onOptionsItemSelected(MenuItem item) {
	switch(item.getItemId()){
	case R.id.share:
		Intent shareIntent = new Intent(Intent.ACTION_SEND);
		shareIntent.setType("text/plain");
		shareIntent.putExtra(Intent.EXTRA_SUBJECT, "subject here");
		shareIntent.putExtra(Intent.EXTRA_TEXT, "body here");
		startActivity(Intent.createChooser(shareIntent, "Share Via"));
		break;
	default:
		break;
	
	}
	return true;
}

}

